import React, { useState } from 'react';
import { Timer } from 'lucide-react';
import { ClockAnimation } from './animations/ClockAnimation';

interface ClockButtonProps {
  type: 'in' | 'out';
  onClick: () => void;
}

export function ClockButton({ type, onClick }: ClockButtonProps) {
  const [isAnimating, setIsAnimating] = useState(false);
  const bgColor = type === 'in' ? 'bg-indigo-600' : 'bg-rose-600';
  const hoverColor = type === 'in' ? 'hover:bg-indigo-700' : 'hover:bg-rose-700';

  const handleClick = () => {
    setIsAnimating(true);
    onClick();
    setTimeout(() => setIsAnimating(false), 2000); // Animation duration
  };

  return (
    <button
      onClick={handleClick}
      className={`${bgColor} ${hoverColor} relative w-48 h-48 rounded-full flex flex-col items-center justify-center text-white transition-colors duration-200 shadow-lg overflow-hidden`}
    >
      <ClockAnimation isActive={isAnimating} type={type} />
      
      <div className={`relative transition-transform duration-300 ${isAnimating ? 'scale-110' : 'scale-100'}`}>
        <Timer className="w-12 h-12 mb-2" />
        <span className="text-xl font-semibold">Clock {type.toUpperCase()}</span>
      </div>
    </button>
  );
}