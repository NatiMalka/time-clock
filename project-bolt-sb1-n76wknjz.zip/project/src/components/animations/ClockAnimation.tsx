import React from 'react';

interface ClockAnimationProps {
  isActive: boolean;
  type: 'in' | 'out';
}

export function ClockAnimation({ isActive, type }: ClockAnimationProps) {
  const color = type === 'in' ? 'indigo' : 'rose';

  return (
    <div className={`absolute inset-0 pointer-events-none transition-opacity duration-500 ${isActive ? 'opacity-100' : 'opacity-0'}`}>
      <div className="relative w-full h-full">
        {/* Clock Face */}
        <div className={`absolute inset-0 border-4 border-${color}-200 rounded-full`}>
          {/* Clock Hand */}
          <div
            className={`absolute left-1/2 top-1/2 w-1 h-[45%] -ml-0.5 -mt-1 origin-bottom ${
              isActive ? 'animate-spin-slow' : ''
            } bg-${color}-400`}
          />
          {/* Center Dot */}
          <div className={`absolute left-1/2 top-1/2 w-3 h-3 -ml-1.5 -mt-1.5 rounded-full bg-${color}-400`} />
        </div>
        
        {/* Ripple Effect */}
        <div className={`absolute inset-0 ${isActive ? 'animate-ping' : ''} rounded-full border-2 border-${color}-300 opacity-75`} />
      </div>
    </div>
  );
}