/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      animation: {
        'spin-slow': 'spin 2s linear infinite',
        'ping': 'ping 1s cubic-bezier(0, 0, 0.2, 1) infinite',
      },
      keyframes: {
        ping: {
          '75%, 100%': {
            transform: 'scale(1.5)',
            opacity: '0',
          },
        },
      },
    },
  },
  plugins: [],
  safelist: [
    'bg-indigo-600',
    'bg-rose-600',
    'hover:bg-indigo-700',
    'hover:bg-rose-700',
    'border-indigo-200',
    'border-rose-200',
    'bg-indigo-400',
    'bg-rose-400',
    'border-indigo-300',
    'border-rose-300',
  ],
};